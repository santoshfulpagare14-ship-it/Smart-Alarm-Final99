package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.AlarmApplication
import com.example.scheduler.AlarmScheduler
import com.example.service.AlarmService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val TAG = "AlarmReceiver"
        const val ACTION_TRIGGER_ALARM = "com.example.alarm.ACTION_TRIGGER_ALARM"
        const val ACTION_SNOOZE = "com.example.alarm.ACTION_SNOOZE"
        const val ACTION_DISMISS = "com.example.alarm.ACTION_DISMISS"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_AUDIO_URI = "extra_audio_uri"
        const val EXTRA_AUDIO_TITLE = "extra_audio_title"
        const val EXTRA_SNOOZE_SECONDS = "extra_snooze_seconds"
        const val EXTRA_VIBRATE = "extra_vibrate"
        const val EXTRA_IS_REPEATING = "extra_is_repeating"
        const val EXTRA_IS_SNOOZED = "extra_is_snoozed"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        val label = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Alarm"
        val audioUri = intent.getStringExtra(EXTRA_AUDIO_URI)
        val audioTitle = intent.getStringExtra(EXTRA_AUDIO_TITLE)
        val snoozeSeconds = intent.getIntExtra(EXTRA_SNOOZE_SECONDS, 300)
        val vibrate = intent.getBooleanExtra(EXTRA_VIBRATE, true)
        val isRepeating = intent.getBooleanExtra(EXTRA_IS_REPEATING, false)
        val isSnoozed = intent.getBooleanExtra(EXTRA_IS_SNOOZED, false)

        Log.d(TAG, "onReceive action=$action alarmId=$alarmId")

        when (action) {
            ACTION_TRIGGER_ALARM -> {
                // Acquire temporary wake lock to ensure CPU stays alive while foreground service launches
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                val wakeLock = powerManager?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "EchoAlarm:AlarmReceiverWakeLock"
                )
                wakeLock?.acquire(5000L)

                // Start Foreground Service for ringing
                val serviceIntent = Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_START_ALARM
                    putExtra(EXTRA_ALARM_ID, alarmId)
                    putExtra(EXTRA_ALARM_LABEL, label)
                    putExtra(EXTRA_AUDIO_URI, audioUri)
                    putExtra(EXTRA_AUDIO_TITLE, audioTitle)
                    putExtra(EXTRA_SNOOZE_SECONDS, snoozeSeconds)
                    putExtra(EXTRA_VIBRATE, vibrate)
                    putExtra(EXTRA_IS_REPEATING, isRepeating)
                    putExtra(EXTRA_IS_SNOOZED, isSnoozed)
                }
                try {
                    ContextCompat.startForegroundService(context, serviceIntent)
                } catch (e: Exception) {
                    Log.e(TAG, "Error starting AlarmService", e)
                }

                // If it's a repeating alarm and not a snooze trigger, schedule the next occurrence
                if (isRepeating && !isSnoozed && alarmId > 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val repo = AlarmApplication.instance.repository
                            val alarm = repo.getAlarmById(alarmId)
                            if (alarm != null && alarm.isEnabled) {
                                AlarmScheduler.scheduleAlarm(context, alarm)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to reschedule repeating alarm", e)
                        }
                    }
                }
            }

            ACTION_SNOOZE -> {
                // Stop the ringing service
                val stopIntent = Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_STOP_ALARM
                }
                context.startService(stopIntent)

                // Schedule snooze alarm
                AlarmScheduler.scheduleSnooze(
                    context = context,
                    alarmId = alarmId,
                    snoozeDurationSeconds = snoozeSeconds,
                    label = label,
                    audioUri = audioUri,
                    audioTitle = audioTitle,
                    vibrate = vibrate,
                    isRepeating = isRepeating
                )
            }

            ACTION_DISMISS -> {
                // Stop the ringing service
                val stopIntent = Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_STOP_ALARM
                }
                context.startService(stopIntent)

                // If one-time non-repeating alarm, disable it in Room DB
                if (!isRepeating && alarmId > 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val repo = AlarmApplication.instance.repository
                            val alarm = repo.getAlarmById(alarmId)
                            if (alarm != null) {
                                repo.update(alarm.copy(isEnabled = false))
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to disable one-time alarm", e)
                        }
                    }
                }
            }
        }
    }
}
