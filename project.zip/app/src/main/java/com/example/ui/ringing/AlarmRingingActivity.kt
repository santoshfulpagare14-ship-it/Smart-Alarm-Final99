package com.example.ui.ringing

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.receiver.AlarmReceiver
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmRingingActivity : ComponentActivity() {

    companion object {
        const val ACTION_FINISH_RINGING_UI = "com.example.alarm.ACTION_FINISH_RINGING_UI"
    }

    private var alarmId: Long = -1L
    private var alarmLabel: String = "Alarm"
    private var audioUri: String? = null
    private var audioTitle: String? = null
    private var snoozeSeconds: Int = 300
    private var vibrate: Boolean = true
    private var isRepeating: Boolean = false

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_FINISH_RINGING_UI) {
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup lockscreen & wakeup flags
        setupLockscreenFlags()

        alarmId = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        alarmLabel = intent.getStringExtra(AlarmReceiver.EXTRA_ALARM_LABEL) ?: "Alarm"
        audioUri = intent.getStringExtra(AlarmReceiver.EXTRA_AUDIO_URI)
        audioTitle = intent.getStringExtra(AlarmReceiver.EXTRA_AUDIO_TITLE)
        snoozeSeconds = intent.getIntExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, 300)
        vibrate = intent.getBooleanExtra(AlarmReceiver.EXTRA_VIBRATE, true)
        isRepeating = intent.getBooleanExtra(AlarmReceiver.EXTRA_IS_REPEATING, false)

        // Register finish broadcast receiver
        val filter = IntentFilter(ACTION_FINISH_RINGING_UI)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(finishReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(finishReceiver, filter)
        }

        setContent {
            MyApplicationTheme(darkTheme = true) {
                AlarmRingingScreen(
                    alarmLabel = alarmLabel,
                    audioTitle = audioTitle ?: "Default Tone",
                    defaultSnoozeSeconds = snoozeSeconds,
                    onSnooze = { customSnoozeSec ->
                        triggerSnooze(customSnoozeSec)
                    },
                    onDismiss = {
                        triggerDismiss()
                    }
                )
            }
        }
    }

    private fun setupLockscreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            keyguardManager?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Requirement 4: While the alarm is ringing, pressing the Volume Down button should dismiss/snooze the alarm
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            triggerSnooze(snoozeSeconds)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun triggerSnooze(durationSeconds: Int = snoozeSeconds) {
        val snoozeIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_SNOOZE
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, alarmLabel)
            putExtra(AlarmReceiver.EXTRA_AUDIO_URI, audioUri)
            putExtra(AlarmReceiver.EXTRA_AUDIO_TITLE, audioTitle)
            putExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, durationSeconds)
            putExtra(AlarmReceiver.EXTRA_VIBRATE, vibrate)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, isRepeating)
        }
        sendBroadcast(snoozeIntent)
        finish()
    }

    private fun triggerDismiss() {
        val dismissIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_DISMISS
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, alarmLabel)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, isRepeating)
        }
        sendBroadcast(dismissIntent)
        finish()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(finishReceiver)
        } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
fun AlarmRingingScreen(
    alarmLabel: String,
    audioTitle: String,
    defaultSnoozeSeconds: Int,
    onSnooze: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var currentTimeString by remember { mutableStateOf("") }
    var currentDateString by remember { mutableStateOf("") }
    var selectedSnoozeSeconds by remember { mutableIntStateOf(defaultSnoozeSeconds) }
    var showCustomSnoozeDialog by remember { mutableStateOf(false) }

    // Pulsing animation for alarm bell
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    // Clock ticker effect
    LaunchedEffect(Unit) {
        val timeFormat = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        while (true) {
            val now = Date()
            currentTimeString = timeFormat.format(now)
            currentDateString = dateFormat.format(now)
            delay(500L)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A1B2F),
                        Color(0xFF10121D),
                        Color(0xFF07080D)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxSize()
        ) {
            // Header: Date and Alarm Label
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 32.dp)
            ) {
                Text(
                    text = currentDateString,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFFA0A5C0),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0x33FFB74D)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Ringing",
                            tint = Color(0xFFFFB74D),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = alarmLabel,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFE082)
                        )
                    }
                }
            }

            // Center: Pulsing Ring + Giant Clock
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(170.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .scale(pulseScale)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color(0x55FF7043),
                                        Color(0x00FF7043)
                                    )
                                ),
                                shape = CircleShape
                            )
                    )
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .background(Color(0xFF2B1F2D), shape = CircleShape)
                            .border(2.dp, Color(0xFFFF7043), shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = "Alarm Active",
                            tint = Color(0xFFFF8A65),
                            modifier = Modifier.size(54.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = currentTimeString,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Tone",
                        tint = Color(0xFF80CBC4),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = audioTitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFB0BEC5),
                        maxLines = 1
                    )
                }
            }

            // Bottom Actions: Volume key tip, Snooze & Stop Buttons
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                // Hardware volume key hint
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0x22FFFFFF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(bottom = 20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeDown,
                            contentDescription = "Volume Down Button",
                            tint = Color(0xFF80D8FF),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Press Volume Down button to snooze",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFB3E5FC)
                        )
                    }
                }

                // Snooze options row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    listOf(60 to "1m", 300 to "5m", 600 to "10m", 900 to "15m").forEach { (sec, label) ->
                        FilledTonalButton(
                            onClick = { onSnooze(sec) },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("quick_snooze_$label"),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (selectedSnoozeSeconds == sec) Color(0xFF3949AB) else Color(0x333949AB),
                                contentColor = Color(0xFFC5CAE9)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(text = "+$label", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Main Snooze Button
                val snoozeText = when {
                    selectedSnoozeSeconds < 60 -> "Snooze (${selectedSnoozeSeconds}s)"
                    selectedSnoozeSeconds % 60 == 0 -> "Snooze (${selectedSnoozeSeconds / 60}m)"
                    else -> "Snooze (${selectedSnoozeSeconds / 60}m ${selectedSnoozeSeconds % 60}s)"
                }
                Button(
                    onClick = { onSnooze(selectedSnoozeSeconds) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("snooze_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF3D5AFE),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(imageVector = Icons.Default.Snooze, contentDescription = "Snooze")
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = snoozeText,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Stop Button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("dismiss_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD32F2F),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop")
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Stop Alarm",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}
