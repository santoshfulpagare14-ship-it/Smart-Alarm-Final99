package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Alarm

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AlarmEditSheet(
    alarm: Alarm?,
    onDismissRequest: () -> Unit,
    onSave: (Alarm) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val isNew = alarm == null
    var hour by remember { mutableIntStateOf(alarm?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(alarm?.minute ?: 0) }
    var label by remember { mutableStateOf(alarm?.label ?: "Morning Alarm") }
    var repeatDaysMask by remember { mutableIntStateOf(alarm?.repeatDaysMask ?: 0) }
    var snoozeSeconds by remember { mutableIntStateOf(alarm?.snoozeDurationSeconds ?: 300) }
    var audioUri by remember { mutableStateOf(alarm?.audioUri) }
    var audioTitle by remember { mutableStateOf(alarm?.audioTitle ?: "System Default Tone") }
    var vibrate by remember { mutableStateOf(alarm?.vibrate ?: true) }

    // Audio preview player state
    var isPreviewPlaying by remember { mutableStateOf(false) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    // Time picker state
    val timePickerState = rememberTimePickerState(
        initialHour = hour,
        initialMinute = minute,
        is24Hour = false
    )

    // Release preview audio player when sheet leaves composition
    DisposableEffect(Unit) {
        onDispose {
            try {
                previewPlayer?.stop()
                previewPlayer?.release()
                previewPlayer = null
            } catch (_: Exception) {}
        }
    }

    fun stopPreview() {
        try {
            previewPlayer?.stop()
            previewPlayer?.release()
            previewPlayer = null
        } catch (_: Exception) {}
        isPreviewPlaying = false
    }

    fun playPreview(uriStr: String?) {
        stopPreview()
        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                if (!uriStr.isNullOrBlank()) {
                    setDataSource(context, Uri.parse(uriStr))
                } else {
                    val defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                    setDataSource(context, defaultUri)
                }
                prepare()
                start()
                setOnCompletionListener {
                    isPreviewPlaying = false
                }
            }
            previewPlayer = player
            isPreviewPlaying = true
        } catch (e: Exception) {
            Log.e("AlarmEditSheet", "Error playing preview audio", e)
            isPreviewPlaying = false
        }
    }

    // Audio file picker launcher
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, flags)
            } catch (e: Exception) {
                Log.w("AlarmEditSheet", "Persistable permission grant failed: ${e.message}")
            }

            var fileName: String? = null
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        fileName = cursor.getString(nameIndex)
                    }
                }
            } catch (e: Exception) {
                Log.w("AlarmEditSheet", "Failed to query filename", e)
            }

            val finalTitle = fileName ?: uri.lastPathSegment ?: "Custom Audio File"
            audioUri = uri.toString()
            audioTitle = finalTitle

            // Play preview immediately so user knows it loaded
            playPreview(uri.toString())
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            stopPreview()
            onDismissRequest()
        },
        sheetState = sheetState,
        dragHandle = null,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Header: Title and Save/Cancel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        stopPreview()
                        onDismissRequest()
                    },
                    modifier = Modifier.testTag("close_sheet_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }

                Text(
                    text = if (isNew) "New Alarm" else "Edit Alarm",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = {
                        stopPreview()
                        val updated = (alarm ?: Alarm()).copy(
                            hour = timePickerState.hour,
                            minute = timePickerState.minute,
                            label = label.trim().ifEmpty { "Alarm" },
                            repeatDaysMask = repeatDaysMask,
                            snoozeDurationSeconds = snoozeSeconds.coerceIn(5, 3600),
                            audioUri = audioUri,
                            audioTitle = audioTitle,
                            vibrate = vibrate,
                            isEnabled = true
                        )
                        onSave(updated)
                    },
                    modifier = Modifier.testTag("save_alarm_button")
                ) {
                    Text("Save")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Time Picker Component
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                TimePicker(
                    state = timePickerState,
                    colors = TimePickerDefaults.colors(
                        clockDialColor = MaterialTheme.colorScheme.surfaceVariant,
                        selectorColor = MaterialTheme.colorScheme.primary,
                        periodSelectorBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Label Input
            OutlinedTextField(
                value = label,
                onValueChange = { label = it },
                label = { Text("Alarm Label") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("alarm_label_input")
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Repeat Days Section
            Text(
                text = "Repeat Days",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            val dayLabels = listOf("M", "T", "W", "T", "F", "S", "S")
            val dayFullNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                dayLabels.forEachIndexed { index, dayLetter ->
                    val isSelected = (repeatDaysMask and (1 shl index)) != 0
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickable {
                                repeatDaysMask = repeatDaysMask xor (1 shl index)
                            }
                            .testTag("day_button_${dayFullNames[index]}")
                    ) {
                        Text(
                            text = dayLetter,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Quick Repeat Presets
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = repeatDaysMask == 0x1F,
                    onClick = { repeatDaysMask = if (repeatDaysMask == 0x1F) 0 else 0x1F },
                    label = { Text("Weekdays", fontSize = 12.sp) }
                )
                FilterChip(
                    selected = repeatDaysMask == 0x60,
                    onClick = { repeatDaysMask = if (repeatDaysMask == 0x60) 0 else 0x60 },
                    label = { Text("Weekends", fontSize = 12.sp) }
                )
                FilterChip(
                    selected = repeatDaysMask == 0x7F,
                    onClick = { repeatDaysMask = if (repeatDaysMask == 0x7F) 0 else 0x7F },
                    label = { Text("Every day", fontSize = 12.sp) }
                )
                if (repeatDaysMask != 0) {
                    TextButton(onClick = { repeatDaysMask = 0 }) {
                        Text("Clear", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Custom Alarm Tone (Audio File Picker)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Ringtone",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Alarm Sound",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Preview audio play/stop button
                        IconButton(
                            onClick = {
                                if (isPreviewPlaying) stopPreview() else playPreview(audioUri)
                            },
                            modifier = Modifier.testTag("preview_audio_button")
                        ) {
                            Icon(
                                imageVector = if (isPreviewPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isPreviewPlaying) "Stop Preview" else "Play Preview",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = audioTitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                stopPreview()
                                audioPickerLauncher.launch(arrayOf("audio/*"))
                            },
                            modifier = Modifier.testTag("pick_audio_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.FolderOpen, contentDescription = "Pick Tone", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Pick Audio File")
                        }

                        if (audioUri != null) {
                            OutlinedButton(
                                onClick = {
                                    stopPreview()
                                    audioUri = null
                                    audioTitle = "System Default Tone"
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Reset")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Snooze Customization Section
            // "User can customize the snooze duration — anywhere from a few seconds up to 1 hour (via slider or input field)"
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Snooze,
                                contentDescription = "Snooze",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Snooze Duration",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = formatDuration(snoozeSeconds),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Slider (from 10 seconds up to 3600 seconds = 1 hour)
                    Slider(
                        value = snoozeSeconds.toFloat(),
                        onValueChange = { snoozeSeconds = it.toInt() },
                        valueRange = 10f..3600f,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("snooze_duration_slider")
                    )

                    // Quick duration presets
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf(
                            15 to "15s",
                            30 to "30s",
                            60 to "1m",
                            300 to "5m",
                            600 to "10m",
                            900 to "15m",
                            1800 to "30m",
                            3600 to "1h"
                        ).forEach { (seconds, label) ->
                            FilterChip(
                                selected = snoozeSeconds == seconds,
                                onClick = { snoozeSeconds = seconds },
                                label = { Text(label, fontSize = 11.sp) },
                                modifier = Modifier.testTag("snooze_chip_$label")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Direct input field for minutes and seconds
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        var minInput by remember(snoozeSeconds) { mutableStateOf((snoozeSeconds / 60).toString()) }
                        var secInput by remember(snoozeSeconds) { mutableStateOf((snoozeSeconds % 60).toString()) }

                        OutlinedTextField(
                            value = minInput,
                            onValueChange = {
                                minInput = it
                                val m = it.toIntOrNull() ?: 0
                                val s = secInput.toIntOrNull() ?: 0
                                snoozeSeconds = (m * 60 + s).coerceIn(5, 3600)
                            },
                            label = { Text("Minutes") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("snooze_minutes_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = secInput,
                            onValueChange = {
                                secInput = it
                                val m = minInput.toIntOrNull() ?: 0
                                val s = it.toIntOrNull() ?: 0
                                snoozeSeconds = (m * 60 + s).coerceIn(5, 3600)
                            },
                            label = { Text("Seconds") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("snooze_seconds_input"),
                            singleLine = true
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Vibration Switch Row
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = "Vibrate",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Vibrate on Alarm",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Switch(
                        checked = vibrate,
                        onCheckedChange = { vibrate = it },
                        modifier = Modifier.testTag("vibrate_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private fun formatDuration(seconds: Int): String {
    return when {
        seconds < 60 -> "${seconds} sec"
        seconds % 60 == 0 -> "${seconds / 60} min"
        else -> "${seconds / 60}m ${seconds % 60}s"
    }
}
