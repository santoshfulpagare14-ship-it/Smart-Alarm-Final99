package com.example.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AlarmApplication
import com.example.data.Alarm
import com.example.receiver.AlarmReceiver
import com.example.scheduler.AlarmScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as AlarmApplication).repository
    val alarms: StateFlow<List<Alarm>> = repository.allAlarms
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _nextAlarmSummary = MutableStateFlow<String?>("No active alarms")
    val nextAlarmSummary: StateFlow<String?> = _nextAlarmSummary.asStateFlow()

    init {
        // Periodically refresh the "Next alarm in X hours" indicator
        viewModelScope.launch {
            while (true) {
                updateNextAlarmSummary(alarms.value)
                delay(30000L) // update every 30s
            }
        }

        viewModelScope.launch {
            alarms.collect { list ->
                updateNextAlarmSummary(list)
            }
        }
    }

    private fun updateNextAlarmSummary(list: List<Alarm>) {
        val activeAlarms = list.filter { it.isEnabled }
        if (activeAlarms.isEmpty()) {
            _nextAlarmSummary.value = "No active alarms"
            return
        }

        val now = System.currentTimeMillis()
        var earliestTrigger = Long.MAX_VALUE
        var earliestAlarm: Alarm? = null

        for (alarm in activeAlarms) {
            val nextTime = AlarmScheduler.calculateNextTriggerMillis(alarm, now)
            if (nextTime < earliestTrigger) {
                earliestTrigger = nextTime
                earliestAlarm = alarm
            }
        }

        if (earliestAlarm != null && earliestTrigger != Long.MAX_VALUE) {
            val diffMs = earliestTrigger - now
            val diffMinutes = (diffMs / (1000 * 60)) % 60
            val diffHours = (diffMs / (1000 * 60 * 60)) % 24
            val diffDays = diffMs / (1000 * 60 * 60 * 24)

            val timeParts = mutableListOf<String>()
            if (diffDays > 0) timeParts.add("${diffDays}d")
            if (diffHours > 0) timeParts.add("${diffHours}h")
            if (diffMinutes > 0 || timeParts.isEmpty()) timeParts.add("${diffMinutes}m")

            _nextAlarmSummary.value = "Next alarm in ${timeParts.joinToString(" ")} (${earliestAlarm.formattedTime()})"
        } else {
            _nextAlarmSummary.value = "No active alarms"
        }
    }

    fun saveAlarm(alarm: Alarm) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            if (alarm.id == 0L) {
                val newId = repository.insert(alarm)
                val insertedAlarm = alarm.copy(id = newId)
                if (insertedAlarm.isEnabled) {
                    AlarmScheduler.scheduleAlarm(context, insertedAlarm)
                }
            } else {
                repository.update(alarm)
                if (alarm.isEnabled) {
                    AlarmScheduler.scheduleAlarm(context, alarm)
                } else {
                    AlarmScheduler.cancelAlarm(context, alarm.id)
                }
            }
        }
    }

    fun toggleAlarm(alarm: Alarm, enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val updated = alarm.copy(isEnabled = enabled)
            repository.update(updated)
            if (enabled) {
                AlarmScheduler.scheduleAlarm(context, updated)
            } else {
                AlarmScheduler.cancelAlarm(context, alarm.id)
            }
        }
    }

    fun deleteAlarm(alarm: Alarm) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            AlarmScheduler.cancelAlarm(context, alarm.id)
            repository.delete(alarm)
        }
    }

    /**
     * Testing aid: Instantly rings the alarm right now so user or emulator
     * can verify audio, snooze, stop button, and volume button handling!
     */
    fun testRingNow(alarm: Alarm) {
        val context = getApplication<Application>()
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, "${alarm.label} (Test Ring)")
            putExtra(AlarmReceiver.EXTRA_AUDIO_URI, alarm.audioUri)
            putExtra(AlarmReceiver.EXTRA_AUDIO_TITLE, alarm.audioTitle)
            putExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, alarm.snoozeDurationSeconds)
            putExtra(AlarmReceiver.EXTRA_VIBRATE, alarm.vibrate)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, alarm.isRepeating())
        }
        context.sendBroadcast(intent)
    }
}
