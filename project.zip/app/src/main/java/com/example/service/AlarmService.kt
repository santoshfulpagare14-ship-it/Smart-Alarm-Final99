package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.AlarmApplication
import com.example.R
import com.example.receiver.AlarmReceiver
import com.example.ui.ringing.AlarmRingingActivity

class AlarmService : Service() {

    companion object {
        const val TAG = "AlarmService"
        const val NOTIFICATION_ID = 2001

        const val ACTION_START_ALARM = "com.example.alarm.service.START"
        const val ACTION_STOP_ALARM = "com.example.alarm.service.STOP"

        @Volatile
        var isRinging = false
            private set
    }

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    private var currentAlarmId: Long = -1L
    private var currentLabel: String = "Alarm"
    private var currentAudioUri: String? = null
    private var currentAudioTitle: String? = null
    private var currentSnoozeSeconds: Int = 300
    private var currentVibrate: Boolean = true
    private var currentIsRepeating: Boolean = false

    // Hardware volume button listener components
    private var volumeChangeReceiver: BroadcastReceiver? = null
    private var volumeContentObserver: ContentObserver? = null
    private var audioManager: AudioManager? = null
    private var lastVolumeLevel: Int = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val action = intent.action
        if (action == ACTION_STOP_ALARM) {
            stopAlarmPlayback()
            stopSelf()
            return START_NOT_STICKY
        }

        if (action == ACTION_START_ALARM) {
            currentAlarmId = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
            currentLabel = intent.getStringExtra(AlarmReceiver.EXTRA_ALARM_LABEL) ?: "Alarm"
            currentAudioUri = intent.getStringExtra(AlarmReceiver.EXTRA_AUDIO_URI)
            currentAudioTitle = intent.getStringExtra(AlarmReceiver.EXTRA_AUDIO_TITLE)
            currentSnoozeSeconds = intent.getIntExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, 300)
            currentVibrate = intent.getBooleanExtra(AlarmReceiver.EXTRA_VIBRATE, true)
            currentIsRepeating = intent.getBooleanExtra(AlarmReceiver.EXTRA_IS_REPEATING, false)

            isRinging = true

            // Start foreground with high-priority notification
            val notification = buildAlarmNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            // Launch audio playback
            startAudioPlayback(currentAudioUri)

            // Start vibration if enabled
            if (currentVibrate) {
                startVibration()
            }

            // Register volume key listener in background
            registerHardwareVolumeListener()

            // Also launch full-screen ringing activity directly if device is interactive/foreground
            launchRingingActivity()
        }

        return START_STICKY
    }

    private fun launchRingingActivity() {
        try {
            val ringingIntent = Intent(this, AlarmRingingActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId)
                putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, currentLabel)
                putExtra(AlarmReceiver.EXTRA_AUDIO_URI, currentAudioUri)
                putExtra(AlarmReceiver.EXTRA_AUDIO_TITLE, currentAudioTitle)
                putExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, currentSnoozeSeconds)
                putExtra(AlarmReceiver.EXTRA_VIBRATE, currentVibrate)
                putExtra(AlarmReceiver.EXTRA_IS_REPEATING, currentIsRepeating)
            }
            startActivity(ringingIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting AlarmRingingActivity directly", e)
        }
    }

    private fun buildAlarmNotification(): Notification {
        // Fullscreen Intent to bring ringing screen over lockscreen
        val fullScreenIntent = Intent(this, AlarmRingingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, currentLabel)
            putExtra(AlarmReceiver.EXTRA_AUDIO_URI, currentAudioUri)
            putExtra(AlarmReceiver.EXTRA_AUDIO_TITLE, currentAudioTitle)
            putExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, currentSnoozeSeconds)
            putExtra(AlarmReceiver.EXTRA_VIBRATE, currentVibrate)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, currentIsRepeating)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            currentAlarmId.toInt(),
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Snooze
        val snoozeIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_SNOOZE
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, currentLabel)
            putExtra(AlarmReceiver.EXTRA_AUDIO_URI, currentAudioUri)
            putExtra(AlarmReceiver.EXTRA_AUDIO_TITLE, currentAudioTitle)
            putExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, currentSnoozeSeconds)
            putExtra(AlarmReceiver.EXTRA_VIBRATE, currentVibrate)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, currentIsRepeating)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            this,
            (currentAlarmId + 100).toInt(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Stop / Dismiss
        val dismissIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_DISMISS
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, currentLabel)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, currentIsRepeating)
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            this,
            (currentAlarmId + 200).toInt(),
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, AlarmApplication.CHANNEL_ID_ALARM)
            .setContentTitle("Alarm: $currentLabel")
            .setContentText("Ringing now • Tap to open or press Volume Down to snooze")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .addAction(0, "Snooze", snoozePendingIntent)
            .addAction(0, "Stop", dismissPendingIntent)
            .build()
    }

    private fun startAudioPlayback(customUriString: String?) {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                isLooping = true

                var dataSourceSet = false
                if (!customUriString.isNullOrBlank()) {
                    try {
                        val parsedUri = Uri.parse(customUriString)
                        setDataSource(this@AlarmService, parsedUri)
                        dataSourceSet = true
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to load custom audio uri $customUriString, falling back to default", e)
                    }
                }

                if (!dataSourceSet) {
                    val defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    setDataSource(this@AlarmService, defaultUri)
                }

                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing MediaPlayer", e)
        }
    }

    private fun startVibration() {
        try {
            val pattern = longArrayOf(0, 800, 400, 800)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibrator = vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting vibrator", e)
        }
    }

    /**
     * Requirement: "Dismiss/Snooze via Volume Button: While the alarm is ringing,
     * pressing the Volume Down button should dismiss/snooze the alarm.
     * Implement a hardware volume key listener in the background service for this"
     */
    private fun registerHardwareVolumeListener() {
        val am = audioManager ?: return
        lastVolumeLevel = am.getStreamVolume(AudioManager.STREAM_ALARM)

        // 1. BroadcastReceiver for system VOLUME_CHANGED_ACTION
        val filter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        volumeChangeReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == "android.media.VOLUME_CHANGED_ACTION") {
                    val prevVolume = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", -1)
                    val currentVolume = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)

                    Log.d(TAG, "Hardware volume change detected: prev=$prevVolume, cur=$currentVolume")
                    // If volume was decreased or changed while alarm is ringing, trigger snooze/dismiss
                    if (currentVolume < prevVolume || (currentVolume != -1 && currentVolume <= prevVolume)) {
                        handleVolumeKeyTrigger()
                    } else if (prevVolume != -1 && currentVolume != -1) {
                        // Any volume button press during active alarm
                        handleVolumeKeyTrigger()
                    }
                }
            }
        }
        try {
            registerReceiver(volumeChangeReceiver, filter)
        } catch (e: Exception) {
            Log.e(TAG, "Error registering volumeChangeReceiver", e)
        }

        // 2. ContentObserver on Settings.System for additional volume changes
        val handler = Handler(Looper.getMainLooper())
        volumeContentObserver = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                super.onChange(selfChange)
                val newVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
                if (lastVolumeLevel != -1 && newVolume < lastVolumeLevel) {
                    Log.d(TAG, "ContentObserver detected volume down: $newVolume < $lastVolumeLevel")
                    handleVolumeKeyTrigger()
                }
                lastVolumeLevel = newVolume
            }
        }
        try {
            contentResolver.registerContentObserver(
                Settings.System.CONTENT_URI,
                true,
                volumeContentObserver!!
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error registering volume ContentObserver", e)
        }
    }

    private fun handleVolumeKeyTrigger() {
        Log.d(TAG, "Hardware Volume Down pressed! Triggering snooze for alarm $currentAlarmId")
        // Trigger snooze via AlarmReceiver
        val snoozeIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_SNOOZE
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, currentLabel)
            putExtra(AlarmReceiver.EXTRA_AUDIO_URI, currentAudioUri)
            putExtra(AlarmReceiver.EXTRA_AUDIO_TITLE, currentAudioTitle)
            putExtra(AlarmReceiver.EXTRA_SNOOZE_SECONDS, currentSnoozeSeconds)
            putExtra(AlarmReceiver.EXTRA_VIBRATE, currentVibrate)
            putExtra(AlarmReceiver.EXTRA_IS_REPEATING, currentIsRepeating)
        }
        sendBroadcast(snoozeIntent)

        // Close ringing activity if open
        val closeIntent = Intent(AlarmRingingActivity.ACTION_FINISH_RINGING_UI)
        sendBroadcast(closeIntent)
    }

    private fun stopAlarmPlayback() {
        isRinging = false
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping mediaPlayer", e)
        }

        try {
            vibrator?.cancel()
            vibrator = null
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling vibrator", e)
        }

        unregisterHardwareVolumeListener()
    }

    private fun unregisterHardwareVolumeListener() {
        if (volumeChangeReceiver != null) {
            try {
                unregisterReceiver(volumeChangeReceiver)
            } catch (e: Exception) {
                Log.e(TAG, "Error unregistering volume receiver", e)
            }
            volumeChangeReceiver = null
        }

        if (volumeContentObserver != null) {
            try {
                contentResolver.unregisterContentObserver(volumeContentObserver!!)
            } catch (e: Exception) {
                Log.e(TAG, "Error unregistering volume observer", e)
            }
            volumeContentObserver = null
        }
    }

    override fun onDestroy() {
        stopAlarmPlayback()
        super.onDestroy()
    }
}
