package com.example.data

import kotlinx.coroutines.flow.Flow

class AlarmRepository(private val alarmDao: AlarmDao) {
    val allAlarms: Flow<List<Alarm>> = alarmDao.getAllAlarms()

    suspend fun getActiveAlarms(): List<Alarm> = alarmDao.getActiveAlarmsSync()

    suspend fun getAlarmById(id: Long): Alarm? = alarmDao.getAlarmById(id)

    fun getAlarmByIdFlow(id: Long): Flow<Alarm?> = alarmDao.getAlarmByIdFlow(id)

    suspend fun insert(alarm: Alarm): Long = alarmDao.insert(alarm)

    suspend fun update(alarm: Alarm) = alarmDao.update(alarm)

    suspend fun delete(alarm: Alarm) = alarmDao.delete(alarm)

    suspend fun deleteById(id: Long) = alarmDao.deleteById(id)

    suspend fun toggleAlarm(alarm: Alarm, enabled: Boolean) {
        alarmDao.update(alarm.copy(isEnabled = enabled))
    }
}
