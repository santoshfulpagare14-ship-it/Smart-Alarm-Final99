package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Locale

@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val label: String = "Alarm",
    val isEnabled: Boolean = true,
    // Bitmask for repeating days:
    // Bit 0 = Monday, Bit 1 = Tuesday, Bit 2 = Wednesday, Bit 3 = Thursday,
    // Bit 4 = Friday, Bit 5 = Saturday, Bit 6 = Sunday.
    // 0 means non-repeating (one-time alarm)
    val repeatDaysMask: Int = 0,
    // Snooze duration in seconds (can be 10 seconds up to 3600 seconds = 1 hour)
    val snoozeDurationSeconds: Int = 300,
    // Custom audio URI (string format from Storage Access Framework)
    val audioUri: String? = null,
    // Display name of custom audio or default
    val audioTitle: String? = null,
    val vibrate: Boolean = true
) {
    fun isRepeating(): Boolean = repeatDaysMask != 0

    fun hasDay(dayIndex: Int): Boolean {
        // dayIndex: 0 for Monday .. 6 for Sunday
        return (repeatDaysMask and (1 shl dayIndex)) != 0
    }

    fun toggleDay(dayIndex: Int): Int {
        return repeatDaysMask xor (1 shl dayIndex)
    }

    fun formattedTime(is24Hour: Boolean = false): String {
        return if (is24Hour) {
            String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
        } else {
            val displayHour = when {
                hour == 0 -> 12
                hour > 12 -> hour - 12
                else -> hour
            }
            val amPm = if (hour < 12) "AM" else "PM"
            String.format(Locale.getDefault(), "%02d:%02d %s", displayHour, minute, amPm)
        }
    }

    fun repeatDaysText(): String {
        if (repeatDaysMask == 0) return "Once"
        if (repeatDaysMask == 0x7F) return "Every day"
        if (repeatDaysMask == 0x1F) return "Weekdays (Mon-Fri)"
        if (repeatDaysMask == 0x60) return "Weekends (Sat-Sun)"

        val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val active = mutableListOf<String>()
        for (i in 0..6) {
            if (hasDay(i)) {
                active.add(dayNames[i])
            }
        }
        return active.joinToString(", ")
    }

    fun snoozeDurationText(): String {
        return when {
            snoozeDurationSeconds < 60 -> "${snoozeDurationSeconds}s"
            snoozeDurationSeconds % 60 == 0 -> "${snoozeDurationSeconds / 60}m"
            else -> "${snoozeDurationSeconds / 60}m ${snoozeDurationSeconds % 60}s"
        }
    }
}
